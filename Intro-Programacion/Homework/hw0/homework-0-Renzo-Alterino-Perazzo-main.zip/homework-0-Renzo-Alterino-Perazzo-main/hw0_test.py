# IMPORTANTE: No modificar ni borrar este archivo
import hw0


def test_hello_world():
    assert hw0.hello_world() == "Hello World!"
